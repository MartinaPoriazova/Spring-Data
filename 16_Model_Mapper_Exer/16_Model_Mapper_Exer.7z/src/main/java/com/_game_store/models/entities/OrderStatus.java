package com._game_store.models.entities;

public enum OrderStatus {
    OPEN, FULFILLED
}
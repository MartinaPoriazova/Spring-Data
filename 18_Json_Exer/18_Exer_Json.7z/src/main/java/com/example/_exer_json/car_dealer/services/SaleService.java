package com.example._exer_json.car_dealer.services;

public interface SaleService {
    void seedSales();

}

package com.example._exer_json.util;

public interface ValidationUtil {

    <E> boolean isValid (E entity);
}

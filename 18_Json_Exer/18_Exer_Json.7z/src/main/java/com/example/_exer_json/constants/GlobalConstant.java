package com.example._exer_json.constants;

public class GlobalConstant {

    public static final String RESOURCE_FILE_PATH = "src/main/resources/files/";
}

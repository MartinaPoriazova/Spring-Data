package com.example._exer_json.car_dealer.services;

import java.io.IOException;

public interface CarService {
    void seedCars() throws IOException;
}

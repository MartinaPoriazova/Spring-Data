package com.example._12_spring_intro_exer.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}

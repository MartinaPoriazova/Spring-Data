package com.example._12_spring_intro_exer.services;

import com.example._12_spring_intro_exer.entities.Author;

public interface AuthorService {

    Author getRandomAuthor();


}

package com.example._12_spring_intro_exer.services;

public class BookService {

    public void insert() {

    }
}

package com.example._12_spring_intro_exer.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}

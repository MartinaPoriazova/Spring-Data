package com.example._xml_exer.util;

public interface ValidationUtil {

    <T> boolean isValid (T entity);
}
